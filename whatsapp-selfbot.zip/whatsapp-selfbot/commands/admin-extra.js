const { card, field } = require("../utils/style");
const { safeGetQuotedMessage, safeGetContact } = require("../utils/safe");

async function requireOwner(message) {
  if (!message.fromMe) {
    await message.reply("🚫 Only the owner can use this command.");
    return false;
  }
  return true;
}

module.exports = [
  {
    name: "block",
    category: "Admin",
    description: "Block a contact (reply to their message)",
    usage: "[reply]",
    async execute(client, message) {
      if (!(await requireOwner(message))) return;
      const quoted = await safeGetQuotedMessage(message);
      const contact = quoted ? await safeGetContact(quoted) : null;
      if (!contact) return message.reply("Reply to the person's message with this command.");
      await contact.block();
      await message.reply(card("Blocked", field("Contact", contact.pushname || contact.number), "⛔"));
    },
  },
  {
    name: "unblock",
    category: "Admin",
    description: "Unblock a contact (reply to their message)",
    usage: "[reply]",
    async execute(client, message) {
      if (!(await requireOwner(message))) return;
      const quoted = await safeGetQuotedMessage(message);
      const contact = quoted ? await safeGetContact(quoted) : null;
      if (!contact) return message.reply("Reply to the person's message with this command.");
      await contact.unblock();
      await message.reply(card("Unblocked", field("Contact", contact.pushname || contact.number), "✅"));
    },
  },
  {
    name: "mute",
    category: "Admin",
    description: "Mute notifications for this chat",
    async execute(client, message) {
      if (!(await requireOwner(message))) return;
      const chat = await message.getChat();
      await chat.mute();
      await message.reply(card("Muted", "", "🔕"));
    },
  },
  {
    name: "unmute",
    category: "Admin",
    description: "Unmute notifications for this chat",
    async execute(client, message) {
      if (!(await requireOwner(message))) return;
      const chat = await message.getChat();
      await chat.unmute();
      await message.reply(card("Unmuted", "", "🔔"));
    },
  },
  {
    name: "leave",
    category: "Admin",
    description: "Leave the current group",
    async execute(client, message) {
      if (!(await requireOwner(message))) return;
      const chat = await message.getChat();
      if (!chat.isGroup) return message.reply("This isn't a group chat.");
      await message.reply(card("Leaving group...", "", "🚪"));
      await chat.leave();
    },
  },
];
