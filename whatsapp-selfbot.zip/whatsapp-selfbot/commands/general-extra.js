const { card, field } = require("../utils/style");

function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${h}h ${m}m ${sec}s`;
}

module.exports = [
  {
    name: "uptime",
    category: "General",
    description: "Show how long the selfbot has been running",
    async execute(client, message) {
      await message.reply(card("Uptime", field("Running for", formatUptime(process.uptime() * 1000)), "⏱️"));
    },
  },
  {
    name: "botinfo",
    category: "General",
    description: "Show info about this selfbot instance",
    async execute(client, message, args, commands) {
      const lines = [
        field("Commands", commands.size),
        field("Prefix", process.env.PREFIX || "$"),
        field("Node.js", process.version),
        field("Uptime", formatUptime(process.uptime() * 1000)),
      ];
      await message.reply(card("Bot Info", lines, "🤖"));
    },
  },
  {
    name: "prefix",
    category: "General",
    description: "Show the current command prefix",
    async execute(client, message) {
      await message.reply(card("Prefix", field("Current", process.env.PREFIX || "$"), "🔧"));
    },
  },
];
