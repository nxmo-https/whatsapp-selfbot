const { card, field } = require("../utils/style");
const { safeGetQuotedMessage, safeGetMentions, safeGetContact } = require("../utils/safe");

module.exports = [
  {
    name: "id",
    category: "Utility",
    description: "Get the raw WhatsApp ID of the current chat, or a mentioned/quoted user",
    async execute(client, message) {
      const quoted = await safeGetQuotedMessage(message);
      if (quoted) {
        const contact = await safeGetContact(quoted);
        return message.reply(card("ID", field(contact?.pushname || "User", quoted.author || quoted.from), "🆔"));
      }
      const mentions = await safeGetMentions(message);
      if (mentions.length > 0) {
        return message.reply(card("ID", field(mentions[0].pushname || "User", mentions[0].id._serialized), "🆔"));
      }
      const chat = await message.getChat();
      await message.reply(card("ID", field("Chat", chat.id._serialized), "🆔"));
    },
  },
  {
    name: "time",
    category: "Utility",
    description: "Show the current server time",
    async execute(client, message) {
      await message.reply(card("Time", field("Now", new Date().toString()), "🕐"));
    },
  },
  {
    name: "seen",
    category: "Utility",
    description: "Mark the current chat as read",
    async execute(client, message) {
      const chat = await message.getChat();
      await chat.sendSeen();
      await message.reply(card("Marked as Read", "", "👁️"));
    },
  },
  {
    name: "typing",
    category: "Utility",
    description: "Simulate typing in this chat for a few seconds",
    usage: "[seconds]",
    async execute(client, message, args) {
      const seconds = Math.min(parseInt(args[0], 10) || 5, 30);
      const chat = await message.getChat();
      await chat.sendStateTyping();
      await message.reply(card("Typing...", field("Duration", `${seconds}s`), "⌨️"));
      setTimeout(() => chat.clearState().catch(() => {}), seconds * 1000);
    },
  },
];
