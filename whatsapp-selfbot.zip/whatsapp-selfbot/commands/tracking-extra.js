const store = require("../utils/store");
const { card, field } = require("../utils/style");

module.exports = [
  {
    name: "editsnipe",
    category: "Tracking",
    description: "Show the last edited message in this chat (before → after)",
    async execute(client, message) {
      const chat = await message.getChat();
      const entry = store.getEdited(chat.id._serialized);
      if (!entry) return message.reply("🕵️ Nothing to editsnipe here.");
      const lines = [
        field("From", entry.author),
        field("Time", new Date(entry.timestamp).toLocaleTimeString()),
        "",
        `${field("Before", "")}`.trim(),
        entry.before || "(empty)",
        "",
        `${field("After", "")}`.trim(),
        entry.after || "(empty)",
      ];
      await message.reply(card("Edit Snipe", lines, "📝"));
    },
  },
  {
    name: "clearsnipe",
    category: "Tracking",
    description: "Clear cached snipe/editsnipe data for this chat",
    async execute(client, message) {
      const chat = await message.getChat();
      store.clearDeleted(chat.id._serialized);
      store.clearEdited(chat.id._serialized);
      await message.reply(card("Cache Cleared", "", "🧼"));
    },
  },
];
