const { card, field } = require("../utils/style");

module.exports = {
  name: "purge",
  category: "Admin",
  description: "Delete your last N messages in this chat, for everyone",
  usage: "<count 1-50>",
  async execute(client, message, args) {
    if (!message.fromMe) {
      return message.reply("🚫 Only the owner can purge messages.");
    }

    const count = parseInt(args[0], 10);
    if (!count || count < 1 || count > 50) {
      return message.reply("Usage: `$purge <count>` — 1 to 50.");
    }

    const chat = await message.getChat();
    const recent = await chat.fetchMessages({ limit: count + 20 });

    // Bug fix: previously assumed fetchMessages() returns oldest-first and
    // just sliced the end of the array. That ordering isn't guaranteed, so
    // it could grab the wrong messages. Sorting explicitly by timestamp
    // (newest first) makes "last N" correct regardless of fetch order.
    const mine = recent
      .filter((m) => m.fromMe && m.id._serialized !== message.id._serialized)
      .sort((a, b) => b.timestamp - a.timestamp);

    const toDelete = mine.slice(0, count);

    let deleted = 0;
    let failed = 0;
    for (const m of toDelete) {
      try {
        await m.delete(true); // true = delete for everyone
        deleted++;
      } catch (err) {
        // Most common cause: WhatsApp only allows delete-for-everyone within
        // a limited time window after sending - older messages fail here,
        // which is a platform limit, not something the bot controls.
        failed++;
        console.warn("[purge] failed to delete a message:", err.message);
      }
    }

    await message.delete(true).catch(() => {});

    const lines = [field("Deleted", deleted)];
    if (failed) lines.push(field("Skipped", `${failed} (too old to delete for everyone)`));
    await chat.sendMessage(card("Purge Complete", lines, "🧹"));
  },
};
