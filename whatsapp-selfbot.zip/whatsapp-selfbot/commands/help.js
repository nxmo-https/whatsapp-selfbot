const { card, bullet, DIVIDER } = require("../utils/style");

const CATEGORY_SYMBOL = {
  Tracking: "🎯",
  General: "⚙️",
  Utility: "🛠️",
  Fun: "🎉",
  Admin: "🛡️",
};

function groupByCategory(commands) {
  const groups = new Map();
  for (const cmd of commands.values()) {
    const list = groups.get(cmd.category) || [];
    list.push(cmd);
    groups.set(cmd.category, list);
  }
  return groups;
}

module.exports = {
  name: "help",
  category: "General",
  description: "List categories, a category's commands, or one command's usage",
  async execute(client, message, args, commands) {
    const prefix = process.env.PREFIX || "$";
    const groups = groupByCategory(commands);

    if (args[0] && commands.has(args[0].toLowerCase())) {
      const cmd = commands.get(args[0].toLowerCase());
      const lines = [
        `Category : ${cmd.category}`,
        `About    : ${cmd.description}`,
        `Usage    : ${prefix}${cmd.name}${cmd.usage ? " " + cmd.usage : ""}`,
      ];
      return message.reply(card(cmd.name, lines, "📘"));
    }

    const categoryMatch = [...groups.keys()].find((c) => c.toLowerCase() === (args[0] || "").toLowerCase());
    if (categoryMatch) {
      const list = groups.get(categoryMatch).sort((a, b) => a.name.localeCompare(b.name));
      const lines = list.map((cmd) => bullet(`${prefix}${cmd.name} — ${cmd.description}`));
      return message.reply(card(categoryMatch, lines, CATEGORY_SYMBOL[categoryMatch] || "🎉"));
    }

    const catLines = [...groups.keys()].map(
      (c) => bullet(`${CATEGORY_SYMBOL[c] || "🎉"} ${c} (${groups.get(c).length})`)
    );
    const body = [
      `${prefix}help <category>`,
      `${prefix}help <command>`,
      DIVIDER,
      ...catLines,
    ];
    return message.reply(card("✨ Command Menu", body, "✨"));
  },
};
