const { card, field } = require("../utils/style");

module.exports = {
  name: "cs",
  category: "Admin",
  description: "Set or clear your WhatsApp status/about text",
  usage: "set <text> | clear",
  async execute(client, message, args) {
    if (!message.fromMe) {
      return message.reply("Only the owner can change the status.");
    }

    const sub = (args[0] || "").toLowerCase();

    if (sub === "set") {
      const text = args.slice(1).join(" ");
      if (!text) return message.reply("Usage: `$cs set <text>`");
      await client.setStatus(text);
      return message.reply(card("Status Updated", field("New status", text), "🛡️"));
    }

    if (sub === "clear") {
      await client.setStatus("");
      return message.reply(card("Status Cleared", "", "🛡️"));
    }

    return message.reply("Usage: `$cs set <text>` or `$cs clear`");
  },
};
