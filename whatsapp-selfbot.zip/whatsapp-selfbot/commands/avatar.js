const { MessageMedia } = require("whatsapp-web.js");
const { field } = require("../utils/style");
const { safeGetQuotedMessage, safeGetMentions } = require("../utils/safe");

module.exports = {
  name: "avatar",
  category: "Utility",
  description: "Get the profile picture of a user (reply/mention) or the current chat",
  async execute(client, message, args) {
    let targetId;

    const quoted = await safeGetQuotedMessage(message);
    if (quoted) {
      targetId = quoted.author || quoted.from;
    } else {
      const mentions = await safeGetMentions(message);
      if (mentions.length > 0) targetId = mentions[0].id._serialized;
    }

    if (!targetId) {
      const chat = await message.getChat();
      targetId = chat.id._serialized;
    }

    try {
      const url = await client.getProfilePicUrl(targetId);
      if (!url) {
        return message.reply("No profile picture found (or it's private).");
      }

      const media = await MessageMedia.fromUrl(url, {
        unsafeMime: true,
        reqOptions: {
          headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" },
          timeout: 15000,
        },
      });

      const chat = await message.getChat();
      await chat.sendMessage(media, {
        caption: field("Avatar", targetId.split("@")[0]),
      });
    } catch (err) {
      console.error("[avatar] error:", err.stack || err);
      await message.reply("Couldn't fetch that avatar — it may be private, or WhatsApp's CDN briefly rejected the request. Try again.");
    }
  },
};
