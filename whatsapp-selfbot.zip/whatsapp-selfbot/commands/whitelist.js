const whitelist = require("../utils/whitelist");
const { card, field } = require("../utils/style");
const { safeGetQuotedMessage } = require("../utils/safe");

async function resolveNumberArg(message, args) {
  if (args[0]) return args[0];
  const quoted = await safeGetQuotedMessage(message);
  if (quoted) return quoted.author || quoted.from;
  return null;
}

module.exports = [
  {
    name: "wl",
    category: "Admin",
    description: "Whitelist a number so they can use every command (owner only)",
    usage: "<number> (or reply to their message)",
    async execute(client, message, args) {
      if (!message.fromMe) return message.reply("Only the owner can manage the whitelist.");
      const target = await resolveNumberArg(message, args);
      if (!target) return message.reply("Usage: `$wl 15551234567` or reply to their message with `$wl`.");
      const id = whitelist.add(target);
      await message.reply(card("Whitelisted", field("Number", id.split("@")[0]), "🛡️"));
    },
  },
  {
    name: "unwl",
    category: "Admin",
    description: "Remove a number from the whitelist (owner only)",
    usage: "<number> (or reply to their message)",
    async execute(client, message, args) {
      if (!message.fromMe) return message.reply("Only the owner can manage the whitelist.");
      const target = await resolveNumberArg(message, args);
      if (!target) return message.reply("Usage: `$unwl 15551234567` or reply to their message with `$unwl`.");
      const existed = whitelist.remove(target);
      await message.reply(
        existed ? card("Removed", field("Number", whitelist.normalize(target).split("@")[0]), "🛡️") : "That number wasn't whitelisted."
      );
    },
  },
  {
    name: "wlist",
    category: "Admin",
    description: "List everyone currently whitelisted",
    async execute(client, message) {
      const all = whitelist.list();
      if (!all.length) return message.reply("No one is whitelisted yet. Use `$wl <number>` to add someone.");
      await message.reply(card("Whitelist", all.map((id) => `🔹 ${id.split("@")[0]}`), "🛡️"));
    },
  },
];
