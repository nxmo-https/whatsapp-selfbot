const { card, field } = require("../utils/style");
const { safeGetQuotedMessage, safeGetMentions, safeGetContact } = require("../utils/safe");

const RIDDLES = [
  { q: "What has keys but no locks, space but no room, and you can enter but not go in?", a: "A keyboard." },
  { q: "The more you take, the more you leave behind. What am I?", a: "Footsteps." },
  { q: "What has a face and two hands but no arms or legs?", a: "A clock." },
  { q: "What gets wetter as it dries?", a: "A towel." },
  { q: "I speak without a mouth and hear without ears. What am I?", a: "An echo." },
];

const TRUTHS = [
  "what's the most embarrassing thing you've ever done in public?",
  "what's a lie you've told that you never got caught for?",
  "who's the last person you stalked on social media?",
  "what's your biggest fear that you've never told anyone?",
  "what's the pettiest reason you've ever been mad at someone?",
];

const DARES = [
  "send the last photo in your camera roll to the group.",
  "text your crush 'I have something to tell you' and don't explain for 10 minutes.",
  "let the group pick your profile picture for the next hour.",
  "speak in an accent for the next 5 messages.",
  "post an embarrassing throwback photo to your status.",
];

const SLAPS = [
  "gets slapped clean across the room. 👋",
  "just got sent flying. 💥",
  "didn't see that one coming.",
  "is now questioning their life choices.",
  "got humbled real quick.",
];

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

async function resolveTarget(message) {
  const quoted = await safeGetQuotedMessage(message);
  if (quoted) {
    const contact = await safeGetContact(quoted);
    if (contact) return contact;
  }
  const mentions = await safeGetMentions(message);
  if (mentions.length > 0) return mentions[0];
  return null;
}

module.exports = [
  {
    name: "riddle",
    category: "Fun",
    description: "Get a random riddle (reply !reveal-worthy, answer included)",
    async execute(client, message) {
      const r = pick(RIDDLES);
      await message.reply(card("Riddle", [field("Q", r.q), field("A", r.a)], "🧩"));
    },
  },
  {
    name: "truth",
    category: "Fun",
    description: "Get a random truth-or-dare truth prompt",
    async execute(client, message) {
      await message.reply(card("Truth", pick(TRUTHS), "🤫"));
    },
  },
  {
    name: "dare",
    category: "Fun",
    description: "Get a random truth-or-dare dare prompt",
    async execute(client, message) {
      await message.reply(card("Dare", pick(DARES), "😈"));
    },
  },
  {
    name: "slap",
    category: "Fun",
    description: "Slap someone (reply to their message, or leave blank)",
    usage: "[reply]",
    async execute(client, message) {
      const target = await resolveTarget(message);
      const line = pick(SLAPS);
      if (target) return message.reply(`@${target.id.user} ${line}`, undefined, { mentions: [target] });
      return message.reply(card("Slap", line, "👋"));
    },
  },
];
