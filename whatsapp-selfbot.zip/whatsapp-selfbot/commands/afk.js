const { card, field } = require("../utils/style");
const { setAfk, clearAfk } = require("../utils/state");

module.exports = [
  {
    name: "afk",
    category: "Admin",
    description: "Mark yourself AFK - auto-replies with your reason when you're mentioned or DM'd",
    usage: "[reason]",
    async execute(client, message, args) {
      if (!message.fromMe) return; // only the owner's own AFK status matters
      setAfk(args.join(" "));
      await message.reply(card("AFK Set", field("Reason", args.join(" ") || "AFK"), "🛡️"));
    },
  },
  {
    name: "afkoff",
    category: "Admin",
    description: "Clear your AFK status",
    async execute(client, message) {
      if (!message.fromMe) return;
      const was = clearAfk();
      await message.reply(was ? card("AFK Cleared", "", "🛡️") : "You weren't AFK.");
    },
  },
];
