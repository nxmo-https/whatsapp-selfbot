const { card, field } = require("../utils/style");
const { safeGetQuotedMessage, safeGetMentions, safeGetContact } = require("../utils/safe");
const { INSULTS, RIZZ, ROASTS, COMPLIMENTS } = require("../utils/wordbanks");

const EIGHTBALL = [
  "It is certain.", "Without a doubt.", "Yes, definitely.", "You may rely on it.",
  "Most likely.", "Outlook good.", "Ask again later.", "Better not tell you now.",
  "Don't count on it.", "My reply is no.", "Very doubtful.", "Signs point to yes.",
];

const FACTS = [
  "bananas are berries, but strawberries aren't.",
  "a day on Venus is longer than a year on Venus.",
  "octopuses have three hearts and blue blood.",
  "honey never spoils.",
  "the Eiffel Tower grows about 15cm taller in summer heat.",
];

const JOKES = [
  "why do programmers prefer dark mode? light attracts bugs.",
  "how many programmers does it take to change a light bulb? none, that's hardware.",
  "why do Java developers wear glasses? because they don't C#.",
  "a SQL query walks into a bar, walks up to two tables and asks: can I join you?",
];

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

async function resolveTarget(message) {
  const quoted = await safeGetQuotedMessage(message);
  if (quoted) {
    const contact = await safeGetContact(quoted);
    if (contact) return contact;
  }
  const mentions = await safeGetMentions(message);
  if (mentions.length > 0) return mentions[0];
  return null;
}

async function sendTargeted(message, target, line) {
  if (target) {
    return message.reply(`@${target.id.user} ${line}`, undefined, { mentions: [target] });
  }
  return message.reply(line);
}

module.exports = [
  {
    name: "insult",
    category: "Fun",
    description: "Playfully insult someone (reply to their message, or leave blank)",
    usage: "[reply]",
    async execute(client, message) {
      await sendTargeted(message, await resolveTarget(message), pick(INSULTS));
    },
  },
  {
    name: "rizz",
    category: "Fun",
    description: "Get a random pickup line",
    async execute(client, message) {
      await message.reply(card("Rizz", pick(RIZZ), "🎉"));
    },
  },
  {
    name: "roast",
    category: "Fun",
    description: "Roast someone (reply to their message, or leave blank)",
    usage: "[reply]",
    async execute(client, message) {
      await sendTargeted(message, await resolveTarget(message), pick(ROASTS));
    },
  },
  {
    name: "compliment",
    category: "Fun",
    description: "Send someone a genuine compliment (reply to their message, or leave blank)",
    usage: "[reply]",
    async execute(client, message) {
      await sendTargeted(message, await resolveTarget(message), pick(COMPLIMENTS));
    },
  },
  {
    name: "8ball",
    category: "Fun",
    description: "Ask the magic 8-ball a question",
    usage: "<question>",
    async execute(client, message, args) {
      if (!args.length) return message.reply("Ask a question first, e.g. `$8ball will it rain today?`");
      await message.reply(card("8-Ball", pick(EIGHTBALL), "🎱"));
    },
  },
  {
    name: "coinflip",
    category: "Fun",
    description: "Flip a coin",
    async execute(client, message) {
      await message.reply(card("Coin Flip", field("Result", Math.random() < 0.5 ? "Heads" : "Tails"), "🎉"));
    },
  },
  {
    name: "dice",
    category: "Fun",
    description: "Roll a die (default d6)",
    usage: "[sides]",
    async execute(client, message, args) {
      const sides = parseInt(args[0], 10) || 6;
      const roll = Math.floor(Math.random() * sides) + 1;
      await message.reply(card("Dice Roll", field(`d${sides}`, roll), "🎉"));
    },
  },
  {
    name: "rate",
    category: "Fun",
    description: "Rate anything out of 10 (purely random, just for fun)",
    usage: "<thing>",
    async execute(client, message, args) {
      const thing = args.join(" ");
      if (!thing) return message.reply("Usage: `$rate pineapple on pizza`");
      await message.reply(card("Rating", field(thing, `${Math.floor(Math.random() * 11)}/10`), "🎉"));
    },
  },
  {
    name: "ship",
    category: "Fun",
    description: "Ship yourself with someone (reply to their message) and get a %",
    usage: "[reply]",
    async execute(client, message) {
      const target = await resolveTarget(message);
      const pct = Math.floor(Math.random() * 101);
      if (target) return message.reply(`You + @${target.id.user}: ${pct}%`, undefined, { mentions: [target] });
      return message.reply(card("Ship", field("You + someone", `${pct}%`), "🎉"));
    },
  },
  {
    name: "fact",
    category: "Fun",
    description: "Get a random fun fact",
    async execute(client, message) {
      await message.reply(card("Fact", pick(FACTS), "🎉"));
    },
  },
  {
    name: "joke",
    category: "Fun",
    description: "Get a random programmer joke",
    async execute(client, message) {
      await message.reply(card("Joke", pick(JOKES), "🎉"));
    },
  },
  {
    name: "wyr",
    category: "Fun",
    description: "Would-you-rather prompt",
    async execute(client, message) {
      const prompts = [
        "give up hot food or cold drinks forever?",
        "have unlimited money or unlimited time?",
        "be able to fly or be invisible?",
        "always be 10 minutes late or 20 minutes early?",
      ];
      await message.reply(card("Would You Rather", pick(prompts), "🎉"));
    },
  },
  {
    name: "hug",
    category: "Fun",
    description: "Hug someone (reply to their message)",
    usage: "[reply]",
    async execute(client, message) {
      await sendTargeted(message, await resolveTarget(message), "gets a hug from you.");
    },
  },
];
