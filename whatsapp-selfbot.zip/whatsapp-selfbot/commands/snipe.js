const store = require("../utils/store");
const { card, field } = require("../utils/style");

module.exports = {
  name: "snipe",
  category: "Tracking",
  description: "Show the last deleted message in this chat",
  async execute(client, message) {
    const chat = await message.getChat();
    const entry = store.getDeleted(chat.id._serialized);

    if (!entry) {
      return message.reply("Nothing to snipe here. (Only messages deleted since the bot started can be caught.)");
    }

    const when = new Date(entry.timestamp).toLocaleTimeString();
    const lines = [
      field("From", entry.author),
      field("Type", entry.type),
      field("Time", when),
      "",
      entry.body || "(no text content — media or unsupported type)",
    ];
    return message.reply(card("Sniped Message", lines, "🎯"));
  },
};
