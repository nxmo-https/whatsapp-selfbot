const { card, field } = require("../utils/style");

module.exports = {
  name: "ping",
  category: "General",
  description: "Check bot latency",
  async execute(client, message) {
    const start = Date.now();
    const sent = await message.reply("Pinging...");
    const latency = Date.now() - start;
    const body = card("Pong", field("Latency", `${latency}ms`), "🏓");
    await sent.edit(body).catch(() => message.reply(body));
  },
};
