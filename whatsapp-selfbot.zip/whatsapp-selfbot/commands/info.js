const { card, field } = require("../utils/style");
const { safeGetQuotedMessage, safeGetMentions, safeGetContact } = require("../utils/safe");

module.exports = {
  name: "info",
  category: "Utility",
  description: "Get info about the current chat, or a mentioned/quoted user",
  async execute(client, message) {
    const chat = await message.getChat();

    let targetContact;
    const quoted = await safeGetQuotedMessage(message);
    if (quoted) {
      targetContact = await safeGetContact(quoted) || (await client.getContactById(quoted.author || quoted.from).catch(() => null));
    } else {
      const mentions = await safeGetMentions(message);
      if (mentions.length > 0) targetContact = mentions[0];
    }

    if (targetContact) {
      const lines = [
        field("Name", targetContact.pushname || targetContact.name || "Unknown"),
        field("Number", targetContact.number),
        field("Business", targetContact.isBusiness ? "Yes" : "No"),
        field("Contact", targetContact.isMyContact ? "Yes" : "No"),
      ];
      return message.reply(card("Contact Info", lines, "👤"));
    }

    if (chat.isGroup) {
      const participants = chat.participants || [];
      const admins = participants.filter((p) => p.isAdmin || p.isSuperAdmin).length;
      const lines = [
        field("Name", chat.name),
        field("ID", chat.id._serialized),
        field("Members", participants.length),
        field("Admins", admins),
        field("Created", chat.createdAt ? new Date(chat.createdAt * 1000).toLocaleString() : "Unknown"),
      ];
      return message.reply(card("Group Info", lines, "👤"));
    }

    const lines = [
      field("Name", chat.name || "Unknown"),
      field("ID", chat.id._serialized),
      field("Unread", chat.unreadCount),
      field("Pinned", chat.pinned ? "Yes" : "No"),
    ];
    return message.reply(card("Chat Info", lines, "👤"));
  },
};
